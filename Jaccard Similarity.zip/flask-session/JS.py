import pandas as pd
from pandas import DataFrame
import csv


books = pd.read_csv('books.csv',header = 0) 

books_attrs = pd.DataFrame(books[['id','title','categories','average_rating']])

#print(books_attrs)

fave_books = 57

def jaccard_similarity(list1, list2):
    set1_ = set(filter(None, list1)) # remove any blanks
    set2_ = set(filter(None, list2))
    intersection = set1_ & set2_
    union = set1_ | set2_
    similarity = float(len(intersection) / len(union))
    return float(similarity)

num_books = len(books)
def books_suggestion(id):
    recommended_books = [];
    #print('If you liked ' + books_attrs.iloc[id-1]['title'] + '\n')
    #print('Similar books that you would like are\n')
    l1 = [books_attrs.iloc[id-1]['categories'],books_attrs.iloc[id - 1]['average_rating']] # (1)
    for counter in range(0,num_books-1): # (2)
        l2 = [books_attrs.iloc[counter]['categories'],books_attrs.iloc[counter]['average_rating']] #(1)
        x = jaccard_similarity(l1,l2) 
        if (x > .4): # (3)
            if (counter != id - 1): # (4)
                recommended_books.append(books_attrs.iloc[counter])
                #print(books_attrs.iloc[counter]['title']) # (5)
    return recommended_books


def getBookList():
    return books[['id','title', 'authors', 'categories','description', 'published_year', 'average_rating','ratings_count']]
    

    
#print(getBookList())
