from flask import *
import sqlite3
import pandas as pd
import JS  
app = Flask(__name__)
import unicodedata

app.secret_key = "datascience"  
with sqlite3.connect('Form.db') as db:
    c = db.cursor()

c.execute('CREATE TABLE IF NOT EXISTS user (username TEXT NOT NULL PRIMARY KEY,password TEX NOT NULL);')
db.commit()
db.close()
@app.route('/')  
def home():  
    return render_template("home.html")  
 
@app.route('/login')  
def login():  
    return render_template("login.html",msg=None)  
 
@app.route('/success',methods = ["POST"])  
def success():  
    if request.method == "POST":  
        with sqlite3.connect('Form.db') as db:
            c = db.cursor()

        #Find user If there is any take proper action
        find_user = ('SELECT * FROM user WHERE username = ? and password = ?')
        c.execute(find_user,[(str(request.form['username'])),(str(request.form['password']))])
        result = c.fetchall()
        print(result)
        if result:
            booklist = JS.getBookList()
            #unicodedata.normalize('NFD', booklist).encode('ascii', 'ignore')  
            print(booklist.head())
            data={}
            data['booklist']=booklist
            data['username']=request.form['username']
            session['username'] = data['username']
            return render_template('profile.html',data=data)
        else:
            return '<p>Please login first</p>' 
      
 
@app.route('/logout')  
def logout():  
    if 'username' in session:  
        session.pop('username',None)  
        return render_template('logout.html')  
    else:  
        return '<p>user already logged out</p>'  
 
@app.route('/profile')  
def profile():  
    if 'email' in session:  
        email = session['email']  
        return render_template('profile.html',name=email)  
    else:  
        return '<p>Please login first</p>'  
  
@app.route('/register')
def register():
    return render_template('register.html') 

@app.route('/createUser',methods = ["POST"])
def createUser():
    if request.method == 'POST':
        with sqlite3.connect('Form.db') as db:
            c = db.cursor()

        #Find Existing username if any take proper action
        find_user = ('SELECT username FROM user WHERE username = ?')
        c.execute(find_user,[(str(request.form['username']))])        
        if c.fetchall():
            return 'Username Taken Try a Diffrent One.'
        else:
            insert = 'INSERT INTO user(username,password) VALUES(?,?)'
            c.execute(insert,[(str(request.form['username'])),(str(request.form['password']))])
            db.commit() 
            msg = 'Account Created!'
             
            return render_template('login.html',msg=msg)

@app.route('/getBookDetails/<bookid>',methods = ["GET"])
def getBookDetails(bookid):
    booklist = JS.getBookList()
    
    bookDetails = booklist[booklist['id']==int(bookid)]
    
    # return 'Book id Invalid'
    bookSuggestion = JS.books_suggestion(int(bookid))
    data = {}
    data['BookDetails']= bookDetails
    data['bookSuggestion'] = bookSuggestion
    print(data['BookDetails'])
    for i in data['BookDetails'].index:
        print('Book : ',data['BookDetails']['id'][i])
    if len(bookDetails) > 0:
        return render_template('bookDetails.html',data=data)
    else:
        return 'Book id Invalid'
if __name__ == '__main__':  
    app.run(debug = True)  