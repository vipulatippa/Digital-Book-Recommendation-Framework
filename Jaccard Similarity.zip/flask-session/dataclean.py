import pandas as pd
data = pd.read_csv('books1.csv')

print(data['title'].isnan())
